module.exports = {
  content: [
	  "*.{html,js,php}",
	  "./report/**/*.{html,js,php}",
    "*.html"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
